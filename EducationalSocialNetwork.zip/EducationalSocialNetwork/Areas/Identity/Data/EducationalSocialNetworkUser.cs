﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace EducationalSocialNetwork.Areas.Identity.Data
{
    // Add profile data for application users by adding properties to the EducationalSocialNetworkUser class
    public class EducationalSocialNetworkUser : IdentityUser
    {
    }
}
